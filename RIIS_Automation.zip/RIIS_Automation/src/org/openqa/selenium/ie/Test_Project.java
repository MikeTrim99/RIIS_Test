package org.openqa.selenium.ie;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;

public class Test_Project {
		

	public static void main(String[] args) 
	{
		
		System.setProperty("webdriver.ie.driver", "C:\\Program Files (x86)\\Selenium\\IEDriverServer.exe");
		WebDriver driver = new InternetExplorerDriver();
		driver.get("https://www.aaalife.com/term-life-insurance-quote-input");
		driver.manage().window().maximize();
		System.out.println(driver.getTitle());
		
			
		WebElement element = driver.findElement(By.id("Zip"));
		element.sendKeys("48313");
		
		element = driver.findElement(By.id("feet"));
		element.sendKeys("4");
		
		element = driver.findElement(By.id("inches"));
		element.sendKeys("7");
		
		element = driver.findElement(By.id("weight"));
		element.sendKeys("350");
		
		element = driver.findElement(By.id("gender"));
		element.sendKeys("Male");
		
		WebElement nicotineUseNo = driver.findElement(By.id("nicotineUseNo"));
		nicotineUseNo.click();
		
		element = driver.findElement(By.id("month"));
		Select select = new Select(element);
		select.selectByVisibleText("January");
		
		element = driver.findElement(By.id("day"));
		Select select1 = new Select(element);
		select1.selectByValue("31");
		
		element = driver.findElement(By.id("year"));
		Select select2 = new Select(element);
		select2.selectByValue("1972");
		
		element = driver.findElement(By.id("coverageAmount"));
		Select select3 = new Select(element);
		select3.selectByValue("950,000");
		
		element = driver.findElement(By.id("termLength"));
		Select select4 = new Select(element);
		select4.selectByVisibleText("25 Years");
		
		WebElement isMemberYes = driver.findElement(By.id("isMemberYes"));
		isMemberYes.click();
		
		element = driver.findElement(By.id("contact_email"));
		element.sendKeys("miketrim99@gmail.com");
		
		
	}

		
	}
